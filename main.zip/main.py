import json
import boto3
import os
import requests
import base64
from io import BytesIO

# Initialize Bedrock clients for both runtime and agent runtime
bedrock_runtime = boto3.client(
    service_name='bedrock-runtime',
    region_name='us-west-2'
)

bedrock_agent_runtime_client = boto3.client(
    service_name='bedrock-agent-runtime',
    region_name='us-west-2'
)


# Global variables for the knowledge base

# Model and knowledge base configurations
modelArn = 'arn:aws:bedrock:us-west-2::foundation-model/meta.llama3-1-405b-instruct-v1:0'
knowledgeBaseId = '7EHLOYLSJL'


# Helper function to validate and fetch a required key from data
def get_required_key(data, key):
    if key not in data:
        raise KeyError(f"Missing required key: {key}")
    return data[key]

# Function to check the input type
def check_input_type(data):
    print("Trying to check input type of the payload")
    if(data.get('input_type') == None):
        print ("Input type not found")
        return False
    try:
        if 'audio' in data.get('input_type'):
            return "audio"
        elif 'text' in data.get('input_type'):
            return "text"
        else:
            return 'text'
    except json.JSONDecodeError:
        print("Invalid input type")
        return False

# Download the audio file from url using authentication token
def download_audio_file(url, token):
    print("Trying to download audio file")
    # Request headers for the audio file download
    headers = {
        'Authorization': f'App {token}'
    }
    # Request the audio file from the provided URL
    response = requests.get(url, headers=headers)
    # Encode the audio file in base64 format
    base64_audio = response.content.encode('base64')
    return audio_file

# Functino to translate speech to text using Sarvam AI
def translate_speech_to_text(data,api_key):
    print("Trying to translate speech to text")
    # Get the Base64-encoded OGG audio file from data
    ogg_audio_file = data.get("question")
    
    # Decode the Base64 string to bytes
    ogg_file_data = base64.b64decode(ogg_audio_file)
    
    # Create a file-like object from the decoded Base64 data
    ogg_file_like_object = BytesIO(ogg_file_data)

    # Read the OGG audio file using soundfile
    data, samplerate = sf.read(ogg_file_like_object)

    # Prepare a BytesIO object to hold the WAV data
    wav_file_like_object = BytesIO()

    # Write the audio data to the BytesIO object in WAV format
    sf.write(wav_file_like_object, data, samplerate, format='WAV')
    wav_file_like_object.seek(0)  # Move to the start of the BytesIO object

    # Prepare the file data for multipart/form-data
    files = {
        'file': ('filename.wav', wav_file_like_object, 'audio/wav'),  # Add the MIME type for wav
    }

    # Prepare the form data
    payload = {
        'prompt': 'null',
        'model': 'saaras:v1',
    }

    # API endpoint
    api_url = "https://api.sarvam.ai/speech-to-text-translate"

    # Set headers, including authorization
    headers = {
        'api-subscription-key': api_key,  # Replace with your actual token
    }
    
    # Make the POST request
    response = requests.post(api_url, data=payload, files=files, headers=headers)

    # Log or return the response
    print("Response from Sarvam AI: " + str(response.text))
    return response.text

# Function to detect the language of the text using llama
def detect_text_lang(prompt):
    
    # Format prompt for language detection
    formatted_prompt = f"""
    You have received a text and you need to detect the language of the text.You also need to translate the text to English. Dont translate if the text is already in English.
    The text below is:
    {prompt}
    Give the answer is the following format:
    Language Detected: <language_detected>
    Translated text: <translated text>
    Don't include any extra comments or text other than the answer format above.
    """
    
    # Request payload for the LLaMA model
    llama_request = json.dumps({
        "prompt": formatted_prompt,
        "max_gen_len": 250,
        "temperature": 0.5,
    })

    # Invoke the LLaMA model using the prepared payload
    response_llama = bedrock_runtime.invoke_model(
        modelId='meta.llama3-1-405b-instruct-v1:0',
        body=llama_request
    )
    
    # Decode the response body from the LLaMA model
    response_body = json.loads(response_llama["body"].read())
    print("Response from llama language translation: " + str(response_body))
    # Extract the language from the response
    language = response_body["generation"].split(":")[1].strip()
    translated_text = response_body["generation"].split(":")[2].strip()
    return [language,translated_text]

# Function to get rag response
def get_rag_response(prompt):
    # Format prompt for retrieval-augmented generation (RAG) with knowledge base
    rag_prompt = f"""
    Human: Please answer the question based on available knowledge.
    Question: {prompt}
    Assistant:
    """
    
    # Call the agent runtime to retrieve knowledge from the knowledge base and generate a response
    response_rag = bedrock_agent_runtime_client.retrieve_and_generate(
        input={
            'text': rag_prompt,
        },
        retrieveAndGenerateConfiguration={
            'type': 'KNOWLEDGE_BASE',   
            'knowledgeBaseConfiguration': {
                'knowledgeBaseId': knowledgeBaseId,
                'modelArn': modelArn,
            }
        }
    )
    
    # Parse the response from the RAG system (Knowledge Base response)
    response_output = response_rag['output']['text']
    return response_output

#Function to save audio response in base64 format to S3
def saveToS3(response,api_key):
    print("Trying to save audio response to S3")
    s3 = boto3.client('s3')
    audio_response = response["audio"]
    audio_response = audio_response.split(",")[1]
    audio_response = audio_response.encode()
    s3.put_object(Bucket='ib.s3.llama-audio-response', Key='audio-response.mp3', Body=audio_response, ACL='public-read', ContentType='audio/mpeg')
    return "https://ib.s3.llama-audio-response-bucket/audio-response.mp3"

#Generate audio response
def generate_audio_response(response,api_key):
    print("Trying to generate audio response")
    url = 'https://api.sarvam.ai/text-to-speech'
    headers = {"api-subscription-key":api_key,"Content-Type": "application/json"}
    payload = {
    "inputs": response[0],
    "target_language_code": response[1],
    "speaker": "meera",
    "pitch": 0,
    "pace": 1.65,
    "loudness": 1.5,
    "speech_sample_rate": 8000,
    "enable_preprocessing": True,
    "model": "bulbul:v1"
    }
    response = requests.post(url, headers=headers, json=payload)
    s3_audio_url = saveToS3(response.json(),api_key)
    return s3_audio_url

#Function to get llama response
def get_llama_response(rag_response,data):
    print("Trying to get llama response")
    # Extract prompt and optional parameters from the request
    model_id = data.get("model", 'meta.llama3-1-8b-instruct-v1:0')
    prompt = data.get("question")
    max_gen_len = data.get("max_gen_len", 512)
    temperature = data.get("temp", 0.5)

    # We structure the prompt for LLaMA such that it incorporates the RAG response and asks LLaMA to augment it.

    formatted_prompt = f"""
    The following information is retrieved from a trusted knowledge base:
    {rag_response}
    
    Based on above response from a trusted knowledge base provide an answer that matches the answer from knowledge base try to be friendly and give a candid response include emoji in your responses.
    Avoid providing code, functions, or structured technical formats or any escape squences like new line or extra quotes.
    Question: {prompt}
    """

    # Request payload for the LLaMA model
    llama_request = json.dumps({
        "prompt": formatted_prompt,
        "max_gen_len": max_gen_len,
        "temperature": temperature,
    })

    # Invoke the LLaMA model using the prepared payload
    response_llama = bedrock_runtime.invoke_model(
        modelId=model_id,
        body=llama_request
    )
   
    
    # Decode the response body from the LLaMA model
    response_body = json.loads(response_llama["body"].read())  
    return response_body["generation"]

def handle_audio_input(data):
    print("Handling audio input")
    sarvam_api_key = os.getenv('SARVAM_API_KEY')
    translated_text = translate_speech_to_text(data,sarvam_api_key)
    rag_response = get_rag_response(translated_text)
    llama_response = get_llama_response(rag_response,data)
    audio_response = generate_audio_response(llama_response,api_key)
    return [rag_response,audio_response]

def handle_text_input(data):
    print("Handling text input")
    prompt = data.get("question")
    text_lang = detect_text_lang(prompt)
    print("Text language detected: " + text_lang[0])
    print("Translated text: " + text_lang[1])
    rag_response = get_rag_response(text_lang[1])
    llama_response = get_llama_response(rag_response,data)
    return [rag_response,llama_response]    

def prase_response(response):
    return response

# Main Lambda handler function
def lambda_handler(event, context):
    
    # Fetch expected authentication key from environment variable
    expected_key = os.getenv('AUTH_KEY')
    
    # Extract the 'Authorization' header from the incoming request
    auth_key = event.get('headers', {}).get('authorization')
    
    # Check for unauthorized access
    if auth_key != expected_key:
        return {
            'statusCode': 401,
            'body': json.dumps({"message": "Unauthorized"})
        }
    
    # Parse request body
    data = json.loads(event.get("body", "{}"))

    # Check if the 'question' is present in the request body
    if 'question' not in data:
        return {
            'statusCode': 400,
            'body': json.dumps({"message": "Prompt not found."})
        }

    # check input type
    input_type = check_input_type(data)
    prompt = data.get("question")

    response = None
    if input_type == "audio":
        response = handle_audio_input(data)
    elif input_type == "text":
        response = handle_text_input(data)
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({"message": "Invalid input type"})
        }
    
    print("Response from the handler: " + str(response))
    parsedResponse = prase_response(response[1])
    
    # Return the combined response: knowledge-based output and LLaMA generation
    return {
        'statusCode': 200,
        'body': json.dumps(
            {
                "question": prompt,
                "input_type": input_type,
                "knowledge_base_response": response[0],
                "augmented_llama_response": parsedResponse
            }
        )
    }